@echo off
setlocal
cd /d "%~dp0"

where powershell.exe >nul 2>nul
if errorlevel 1 (
    echo Windows PowerShell was not found.
    echo This tool requires Windows PowerShell 5.1, which is included with Windows 10/11.
    pause
    exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0WRS2TerrainImporter.ps1"
if errorlevel 1 (
    echo.
    echo The importer closed with an error.
    pause
)
endlocal
