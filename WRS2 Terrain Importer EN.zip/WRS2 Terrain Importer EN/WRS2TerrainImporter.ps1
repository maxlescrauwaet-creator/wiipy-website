﻿param(
    [string]$BaseDir = $PSScriptRoot
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$cs = @'
using System;
using System.IO;
using System.Net;
using System.Text;
using System.Drawing;
using System.Drawing.Imaging;
using System.Collections.Generic;

public static class Wrs2TerrainCore
{
    const int Res = 2049;
    const double SizeY = 1999.0;
    const long Base3 = 16581375L; // 255^3
    const long Base2 = 65025L;    // 255^2
    const double EarthR = 6378137.0;

    class Tile
    {
        public byte[] Data;
        public int Stride;
        public int Width;
        public int Height;
    }

    static double Deg2Rad(double d) { return d * Math.PI / 180.0; }
    static double Rad2Deg(double r) { return r * 180.0 / Math.PI; }

    static double LonToTileX(double lon, int z)
    {
        double n = Math.Pow(2.0, z);
        return (lon + 180.0) / 360.0 * n;
    }

    static double LatToTileY(double lat, int z)
    {
        double n = Math.Pow(2.0, z);
        double r = Deg2Rad(lat);
        return (1.0 - Math.Log(Math.Tan(r) + 1.0 / Math.Cos(r)) / Math.PI) / 2.0 * n;
    }

    static string TileKey(int x, int y) { return x.ToString() + ":" + y.ToString(); }

    static Tile LoadTile(string path)
    {
        using (Bitmap src = new Bitmap(path))
        using (Bitmap bmp = new Bitmap(src.Width, src.Height, PixelFormat.Format32bppArgb))
        {
            using (Graphics g = Graphics.FromImage(bmp)) g.DrawImageUnscaled(src, 0, 0);
            Rectangle rect = new Rectangle(0, 0, bmp.Width, bmp.Height);
            BitmapData bd = bmp.LockBits(rect, ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
            try
            {
                byte[] raw = new byte[Math.Abs(bd.Stride) * bmp.Height];
                System.Runtime.InteropServices.Marshal.Copy(bd.Scan0, raw, 0, raw.Length);
                return new Tile { Data = raw, Stride = bd.Stride, Width = bmp.Width, Height = bmp.Height };
            }
            finally { bmp.UnlockBits(bd); }
        }
    }

    static double HeightAt(Dictionary<string,Tile> tiles, int z, int globalX, int globalY)
    {
        int worldPx = (1 << z) * 256;
        globalX = ((globalX % worldPx) + worldPx) % worldPx;
        if (globalY < 0) globalY = 0;
        if (globalY >= worldPx) globalY = worldPx - 1;

        int tx = globalX / 256;
        int ty = globalY / 256;
        int px = globalX & 255;
        int py = globalY & 255;
        Tile t;
        if (!tiles.TryGetValue(TileKey(tx,ty), out t)) throw new Exception("Missing DEM tile " + tx + "/" + ty);
        int i = py * t.Stride + px * 4;
        byte b = t.Data[i + 0];
        byte g = t.Data[i + 1];
        byte r = t.Data[i + 2];
        return r * 256.0 + g + b / 256.0 - 32768.0;
    }

    static double SampleHeight(Dictionary<string,Tile> tiles, int z, double lat, double lon)
    {
        double gx = LonToTileX(lon, z) * 256.0;
        double gy = LatToTileY(lat, z) * 256.0;
        int x0 = (int)Math.Floor(gx);
        int y0 = (int)Math.Floor(gy);
        double fx = gx - x0;
        double fy = gy - y0;
        double h00 = HeightAt(tiles, z, x0, y0);
        double h10 = HeightAt(tiles, z, x0 + 1, y0);
        double h01 = HeightAt(tiles, z, x0, y0 + 1);
        double h11 = HeightAt(tiles, z, x0 + 1, y0 + 1);
        double a = h00 + (h10 - h00) * fx;
        double b = h01 + (h11 - h01) * fx;
        return a + (b - a) * fy;
    }

    static void DownloadTiles(double lat, double lon, double realSizeM, int z, string dir, Dictionary<string,Tile> tiles)
    {
        double half = realSizeM / 2.0 + 100.0;
        double dLat = Rad2Deg(half / EarthR);
        double dLon = Rad2Deg(half / (EarthR * Math.Cos(Deg2Rad(lat))));
        double north = Math.Min(85.0, lat + dLat);
        double south = Math.Max(-85.0, lat - dLat);
        double west = lon - dLon;
        double east = lon + dLon;
        int xMin = (int)Math.Floor(LonToTileX(west, z)) - 1;
        int xMax = (int)Math.Floor(LonToTileX(east, z)) + 1;
        int yMin = (int)Math.Floor(LatToTileY(north, z)) - 1;
        int yMax = (int)Math.Floor(LatToTileY(south, z)) + 1;
        int n = 1 << z;

        Directory.CreateDirectory(dir);
        using (WebClient wc = new WebClient())
        {
            wc.Headers.Add("User-Agent", "WRS2-Terrain-Importer/1.0");
            for (int y = yMin; y <= yMax; y++)
            {
                if (y < 0 || y >= n) continue;
                for (int x0 = xMin; x0 <= xMax; x0++)
                {
                    int x = ((x0 % n) + n) % n;
                    string key = TileKey(x,y);
                    if (tiles.ContainsKey(key)) continue;
                    string file = Path.Combine(dir, z + "_" + x + "_" + y + ".png");
                    if (!File.Exists(file))
                    {
                        string url = "https://s3.amazonaws.com/elevation-tiles-prod/terrarium/" + z + "/" + x + "/" + y + ".png";
                        wc.DownloadFile(url, file);
                    }
                    tiles[key] = LoadTile(file);
                }
            }
        }
    }

    static int FindBytes(byte[] hay, byte[] needle, int start)
    {
        for (int i = Math.Max(0,start); i <= hay.Length - needle.Length; i++)
        {
            bool ok = true;
            for (int j=0; j<needle.Length; j++) if (hay[i+j] != needle[j]) { ok=false; break; }
            if (ok) return i;
        }
        return -1;
    }

    static int ReadBE32(byte[] d, int p)
    {
        return (d[p]<<24) | (d[p+1]<<16) | (d[p+2]<<8) | d[p+3];
    }

    static int PngEnd(byte[] d, int off)
    {
        int p = off + 8;
        while (p + 12 <= d.Length)
        {
            int len = ReadBE32(d,p);
            string type = Encoding.ASCII.GetString(d, p+4, 4);
            p += 12 + len;
            if (type == "IEND") return p;
        }
        throw new Exception("Invalid embedded PNG.");
    }

    static byte[] PatchBin(byte[] template, byte[] png)
    {
        byte[] field = Encoding.ASCII.GetBytes("heightmapData");
        int f = FindBytes(template, field, 0);
        if (f < 0) throw new Exception("heightmapData was not found in flat.bin.");
        byte[] sig = new byte[]{137,80,78,71,13,10,26,10};
        int off = FindBytes(template, sig, f);
        while (off >= 0)
        {
            if (off + 24 < template.Length && Encoding.ASCII.GetString(template, off+12, 4) == "IHDR")
            {
                int w = ReadBE32(template, off+16);
                int h = ReadBE32(template, off+20);
                if (w == Res && h == Res) break;
            }
            off = FindBytes(template, sig, off + 8);
        }
        if (off < 10) throw new Exception("2049x2049 heightmap PNG was not found in flat.bin.");
        int end = PngEnd(template, off);
        int oldLen = end - off;
        if (template[off-10] != 0x0F || template[off-1] != 0x02) throw new Exception("Unsupported WRS2 BinaryFormatter layout.");
        int declared = BitConverter.ToInt32(template, off-5);
        if (declared != oldLen) throw new Exception("Unexpected heightmap byte array length.");

        using (MemoryStream ms = new MemoryStream())
        {
            ms.Write(template, 0, off-5);
            byte[] lb = BitConverter.GetBytes(png.Length);
            ms.Write(lb, 0, 4);
            ms.WriteByte(template[off-1]);
            ms.Write(png, 0, png.Length);
            ms.Write(template, end, template.Length-end);
            return ms.ToArray();
        }
    }

    public static string Generate(double lat, double lon, double realSizeM, double baseY, double verticalScale, string templatePath, string outputPath, string tempDir)
    {
        if (realSizeM < 500 || realSizeM > 20000) throw new Exception("Area size must be between 500 and 20000 metres.");
        if (verticalScale <= 0 || verticalScale > 5) throw new Exception("Vertical scale must be greater than 0 and at most 5.");
        if (!File.Exists(templatePath)) throw new Exception("Template flat.bin was not found.");

        int zoom = 14;
        Dictionary<string,Tile> tiles = new Dictionary<string,Tile>();
        DownloadTiles(lat, lon, realSizeM, zoom, tempDir, tiles);

        double[] h = new double[Res * Res];
        double min = Double.PositiveInfinity, max = Double.NegativeInfinity;
        double half = realSizeM / 2.0;
        double step = realSizeM / (Res - 1.0);
        double cosLat = Math.Cos(Deg2Rad(lat));

        for (int y=0; y<Res; y++)
        {
            double dz = half - y * step; // image top = north = +Z
            double plat = lat + Rad2Deg(dz / EarthR);
            for (int x=0; x<Res; x++)
            {
                double dx = -half + x * step;
                double plon = lon + Rad2Deg(dx / (EarthR * cosLat));
                double v = SampleHeight(tiles, zoom, plat, plon);
                int idx = y * Res + x;
                h[idx] = v;
                if (v < min) min = v;
                if (v > max) max = v;
            }
        }

        double outMax = baseY + (max - min) * verticalScale;
        if (baseY < 0 || outMax >= SizeY)
            throw new Exception(String.Format("Terrain would use Y={0:F1}..{1:F1} m. Reduce vertical scale or base height.", baseY, outMax));

        string pngPath = Path.Combine(tempDir, "wrs2_heightmap.png");
        using (Bitmap bmp = new Bitmap(Res, Res, PixelFormat.Format32bppArgb))
        {
            Rectangle rect = new Rectangle(0,0,Res,Res);
            BitmapData bd = bmp.LockBits(rect, ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
            try
            {
                byte[] raw = new byte[Math.Abs(bd.Stride) * Res];
                for (int y=0; y<Res; y++)
                {
                    int row = y * bd.Stride;
                    for (int x=0; x<Res; x++)
                    {
                        double wy = baseY + (h[y*Res+x] - min) * verticalScale;
                        double norm = wy / SizeY;
                        if (norm < 0) norm = 0;
                        if (norm >= 1) norm = (Base3 - 1.0) / Base3;
                        long n = (long)Math.Round(norm * Base3);
                        if (n < 0) n = 0; if (n >= Base3) n = Base3-1;
                        byte r = (byte)(n / Base2);
                        long rem = n - r * Base2;
                        byte g = (byte)(rem / 255L);
                        byte b = (byte)(rem - g * 255L);
                        int i = row + x*4;
                        raw[i+0] = b; raw[i+1] = g; raw[i+2] = r; raw[i+3] = 0;
                    }
                }
                System.Runtime.InteropServices.Marshal.Copy(raw, 0, bd.Scan0, raw.Length);
            }
            finally { bmp.UnlockBits(bd); }
            bmp.Save(pngPath, ImageFormat.Png);
        }

        byte[] pngBytes = File.ReadAllBytes(pngPath);
        byte[] template = File.ReadAllBytes(templatePath);
        byte[] patched = PatchBin(template, pngBytes);
        File.WriteAllBytes(outputPath, patched);

        return String.Format("Done! Real elevation: {0:F1}..{1:F1} m | WRS2: {2:F1}..{3:F1} m", min, max, baseY, outMax);
    }
}
'@

Add-Type -TypeDefinition $cs -ReferencedAssemblies System.Drawing

function Get-SafeName([string]$Text) {
    if ([string]::IsNullOrWhiteSpace($Text)) { return 'terrain' }
    $norm = $Text.Normalize([Text.NormalizationForm]::FormD)
    $sb = New-Object Text.StringBuilder
    foreach ($c in $norm.ToCharArray()) {
        if ([Globalization.CharUnicodeInfo]::GetUnicodeCategory($c) -ne [Globalization.UnicodeCategory]::NonSpacingMark) {
            [void]$sb.Append($c)
        }
    }
    $s = $sb.ToString().Normalize([Text.NormalizationForm]::FormC).ToLowerInvariant()
    $s = [regex]::Replace($s, '[^a-z0-9]+', '_').Trim('_')
    if (-not $s) { $s = 'terrain' }
    return $s
}

function Search-Place([string]$Query) {
    if ([string]::IsNullOrWhiteSpace($Query)) { throw 'Enter a location first.' }
    $encoded = [Uri]::EscapeDataString($Query)
    $url = "https://nominatim.openstreetmap.org/search?q=$encoded&format=jsonv2&limit=1"
    $headers = @{ 'User-Agent' = 'WRS2-Terrain-Importer/1.0' }
    $r = Invoke-RestMethod -Uri $url -Headers $headers -Method Get -TimeoutSec 30
    if (-not $r -or $r.Count -eq 0) { throw "Location not found: $Query" }
    return $r[0]
}

$form = New-Object Windows.Forms.Form
$form.Text = 'WRS2 Terrain Importer'
$form.Size = New-Object Drawing.Size(640, 515)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.Font = New-Object Drawing.Font('Segoe UI', 9)

$title = New-Object Windows.Forms.Label
$title.Text = 'WRS2 Real-World Terrain Importer'
$title.Font = New-Object Drawing.Font('Segoe UI', 16, [Drawing.FontStyle]::Bold)
$title.AutoSize = $true
$title.Location = New-Object Drawing.Point(22, 18)
$form.Controls.Add($title)

$sub = New-Object Windows.Forms.Label
$sub.Text = 'Search a real place and generate a WRS2 .bin terrain file.'
$sub.AutoSize = $true
$sub.Location = New-Object Drawing.Point(25, 55)
$form.Controls.Add($sub)

$lblLoc = New-Object Windows.Forms.Label
$lblLoc.Text = 'Location:'
$lblLoc.AutoSize = $true
$lblLoc.Location = New-Object Drawing.Point(25, 94)
$form.Controls.Add($lblLoc)

$txtLoc = New-Object Windows.Forms.TextBox
$txtLoc.Text = ''
$txtLoc.Location = New-Object Drawing.Point(25, 116)
$txtLoc.Size = New-Object Drawing.Size(445, 27)
$form.Controls.Add($txtLoc)

$btnSearch = New-Object Windows.Forms.Button
$btnSearch.Text = 'Search'
$btnSearch.Location = New-Object Drawing.Point(485, 114)
$btnSearch.Size = New-Object Drawing.Size(115, 30)
$form.Controls.Add($btnSearch)

$found = New-Object Windows.Forms.Label
$found.Text = 'Not searched yet.'
$found.AutoEllipsis = $true
$found.Size = New-Object Drawing.Size(575, 38)
$found.Location = New-Object Drawing.Point(25, 150)
$form.Controls.Add($found)

$lblLat = New-Object Windows.Forms.Label
$lblLat.Text = 'Latitude:'
$lblLat.AutoSize = $true
$lblLat.Location = New-Object Drawing.Point(25, 198)
$form.Controls.Add($lblLat)

$txtLat = New-Object Windows.Forms.TextBox
$txtLat.Text = ''
$txtLat.Location = New-Object Drawing.Point(90, 194)
$txtLat.Size = New-Object Drawing.Size(170, 27)
$form.Controls.Add($txtLat)

$lblLon = New-Object Windows.Forms.Label
$lblLon.Text = 'Longitude:'
$lblLon.AutoSize = $true
$lblLon.Location = New-Object Drawing.Point(285, 198)
$form.Controls.Add($lblLon)

$txtLon = New-Object Windows.Forms.TextBox
$txtLon.Text = ''
$txtLon.Location = New-Object Drawing.Point(365, 194)
$txtLon.Size = New-Object Drawing.Size(170, 27)
$form.Controls.Add($txtLon)

$coordTip = New-Object Windows.Forms.Label
$coordTip.Text = 'You can adjust the coordinates before generating the terrain.'
$coordTip.AutoSize = $true
$coordTip.ForeColor = [Drawing.Color]::DimGray
$coordTip.Location = New-Object Drawing.Point(25, 226)
$form.Controls.Add($coordTip)

$script:compactMode = $false

$btnScaleMode = New-Object Windows.Forms.Button
$btnScaleMode.Text = 'Scale mode: 1:1 (2458 m area)'
$btnScaleMode.Location = New-Object Drawing.Point(25, 260)
$btnScaleMode.Size = New-Object Drawing.Size(280, 34)
$form.Controls.Add($btnScaleMode)

$scaleInfo = New-Object Windows.Forms.Label
$scaleInfo.Text = 'True 1:1 scale: imports approximately 2458 x 2458 m of real terrain.'
$scaleInfo.Size = New-Object Drawing.Size(575, 38)
$scaleInfo.ForeColor = [Drawing.Color]::DimGray
$scaleInfo.Location = New-Object Drawing.Point(25, 300)
$form.Controls.Add($scaleInfo)

$btnGenerate = New-Object Windows.Forms.Button
$btnGenerate.Text = 'Generate terrain .bin'
$btnGenerate.Font = New-Object Drawing.Font('Segoe UI', 10, [Drawing.FontStyle]::Bold)
$btnGenerate.Location = New-Object Drawing.Point(25, 342)
$btnGenerate.Size = New-Object Drawing.Size(575, 42)
$form.Controls.Add($btnGenerate)

$status = New-Object Windows.Forms.Label
$status.Text = 'Ready.'
$status.Size = New-Object Drawing.Size(575, 70)
$status.Location = New-Object Drawing.Point(25, 400)
$form.Controls.Add($status)

$script:lastPlace = $null

$btnScaleMode.Add_Click({
    $script:compactMode = -not $script:compactMode
    if ($script:compactMode) {
        $btnScaleMode.Text = 'Scale mode: 0.41 (6000 m area)'
        $scaleInfo.Text = 'Compact mode: imports 6000 x 6000 m and scales X/Z and height together to ~0.41.'
    }
    else {
        $btnScaleMode.Text = 'Scale mode: 1:1 (2458 m area)'
        $scaleInfo.Text = 'True 1:1 scale: imports approximately 2458 x 2458 m of real terrain.'
    }
})

function Parse-Coordinate([string]$Text, [string]$Name) {
    if ([string]::IsNullOrWhiteSpace($Text)) { throw "$Name is empty. Search for a place first or enter coordinates." }
    $clean = $Text.Trim().Replace(',', '.')
    $value = 0.0
    if (-not [double]::TryParse($clean, [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$value)) {
        throw "Invalid $Name value: $Text"
    }
    return $value
}

$btnSearch.Add_Click({
    try {
        $form.UseWaitCursor = $true
        $status.Text = 'Searching...'
        [Windows.Forms.Application]::DoEvents()
        $script:lastPlace = Search-Place $txtLoc.Text
        $txtLat.Text = [string]$script:lastPlace.lat
        $txtLon.Text = [string]$script:lastPlace.lon
        $found.Text = "Found: $($script:lastPlace.display_name)"
        $status.Text = 'Location found. You can adjust latitude and longitude if needed.'
    }
    catch {
        $status.Text = 'Error: ' + $_.Exception.Message
        [Windows.Forms.MessageBox]::Show($_.Exception.Message, 'Search error', 'OK', 'Error') | Out-Null
    }
    finally { $form.UseWaitCursor = $false }
})

$btnGenerate.Add_Click({
    try {
        $btnGenerate.Enabled = $false
        $btnSearch.Enabled = $false
        $form.UseWaitCursor = $true

        if ([string]::IsNullOrWhiteSpace($txtLat.Text) -or [string]::IsNullOrWhiteSpace($txtLon.Text)) {
            $status.Text = 'Finding location...'
            [Windows.Forms.Application]::DoEvents()
            $script:lastPlace = Search-Place $txtLoc.Text
            $txtLat.Text = [string]$script:lastPlace.lat
            $txtLon.Text = [string]$script:lastPlace.lon
            $found.Text = "Found: $($script:lastPlace.display_name)"
        }

        $lat = Parse-Coordinate $txtLat.Text 'latitude'
        $lon = Parse-Coordinate $txtLon.Text 'longitude'
        if ($lat -lt -85 -or $lat -gt 85) { throw 'Latitude must be between -85 and 85 degrees.' }
        if ($lon -lt -180 -or $lon -gt 180) { throw 'Longitude must be between -180 and 180 degrees.' }

        $template = Join-Path $BaseDir 'flat.bin'
        if (-not (Test-Path -LiteralPath $template)) { throw "flat.bin is missing from the importer folder." }

        $safe = Get-SafeName $txtLoc.Text
        $output = Join-Path $BaseDir ($safe + '.bin')
        if (Test-Path -LiteralPath $output) {
            $ans = [Windows.Forms.MessageBox]::Show("$safe.bin already exists. Replace it?", 'File exists', 'YesNo', 'Question')
            if ($ans -ne [Windows.Forms.DialogResult]::Yes) { throw 'Generation cancelled.' }
        }

        $temp = Join-Path ([IO.Path]::GetTempPath()) ('wrs2terrain_' + [Guid]::NewGuid().ToString('N'))
        New-Item -ItemType Directory -Path $temp | Out-Null
        try {
            $realSize = 2457.6
            $verticalScale = 1.0
            $modeName = '1:1'
            if ($script:compactMode) {
                $realSize = 6000.0
                $verticalScale = 2457.6 / 6000.0
                $modeName = '0.41 compact'
            }

            $status.Text = "Downloading elevation data and building 2049x2049 terrain ($modeName mode)... This can take a minute."
            [Windows.Forms.Application]::DoEvents()
            $msg = [Wrs2TerrainCore]::Generate($lat, $lon, $realSize, 100.0, $verticalScale, $template, $output, $temp)
            $status.Text = "$msg`r`nMode: $modeName | Saved as: $safe.bin"
            [Windows.Forms.MessageBox]::Show("Terrain generated successfully!`r`n`r`nFile: $output`r`n`r`nKeep a backup of your WRS2 save before replacing its .bin file.", 'Done', 'OK', 'Information') | Out-Null
        }
        finally {
            Remove-Item -LiteralPath $temp -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
    catch {
        if ($_.Exception.Message -ne 'Generation cancelled.') {
            $status.Text = 'Error: ' + $_.Exception.Message
            [Windows.Forms.MessageBox]::Show($_.Exception.Message, 'Generation error', 'OK', 'Error') | Out-Null
        } else { $status.Text = 'Cancelled.' }
    }
    finally {
        $btnGenerate.Enabled = $true
        $btnSearch.Enabled = $true
        $form.UseWaitCursor = $false
    }
})

[void]$form.ShowDialog()
