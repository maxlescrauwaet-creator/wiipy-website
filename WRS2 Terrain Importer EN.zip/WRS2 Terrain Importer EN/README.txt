1. Extract the ZIP folder.
2. Launch Winter Resort Simulator 2 and create a new Flat Map sandbox savegame.
3. Save the game.
   You can either choose your own savegame name or keep the default one.
4. Close Winter Resort Simulator 2.
5. Run WRS 2 Terrain Importer.bat.
6. Search for any place in the world.
   Keep in mind that the standard WRS2 map size is approximately 2458 m × 2458 m.
   You can search for:
   - mountain peaks
   - ski resorts
   - towns
   - villages
   - landmarks
   - other specific locations
7. Click Search.
8. Check whether the importer found the correct location.
   If it found the wrong place, you can manually enter the correct Latitude and Longitude.
9. Click Generate terrain .bin.
10. A new .bin file will appear inside the importer folder.
    The file name will be based on the location you searched for.
11. Open your WRS2 savegames folder and replace the .bin file created by the game with the newly generated .bin file.

   Important: the new file must have the same name as the original .bin referenced by your savegame.